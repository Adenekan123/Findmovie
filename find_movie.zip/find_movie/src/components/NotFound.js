import React from "react";

const NotFound = () => <div>Not Found</div>;

export default NotFound;